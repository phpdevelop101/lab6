<footer>
    
    <p>&copy; Copyright 2017, All rights reserved, Book Lovers  Club </p>
    
</footer>